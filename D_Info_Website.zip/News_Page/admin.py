from django.contrib import admin

from News_Page.models import News

# Register your models here.
admin.site.register(News)