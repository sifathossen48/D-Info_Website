from django.contrib import admin
from ReturnPolicy.models import Return_Policy

# Register your models here.
admin.site.register(Return_Policy)